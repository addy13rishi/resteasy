package com.example.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.bean.Orderlist;
import com.example.dao.AdminDao;
import com.example.dao.Logindao;
import com.example.dao.QueryDao;  
@RestController  
@RequestMapping("/")
public class SpringBootJdbcController {  
	@Autowired  
	JdbcTemplate jdbc;    

	String userrole="other";

	@RequestMapping("/loginDBCall")  
	public String loginCall(){  
		Scanner myObj = new Scanner(System.in);
		System.out.println("Enter username");

		String userName = myObj.nextLine();
		if(userName!=null) {
			System.out.println("Enter Password");

			String pass = myObj.nextLine(); 

			//myObj.close();
			if(userName.isEmpty() || pass.isEmpty()) {
				System.out.println("Please enter correct credentials");
			}else
			{
				Logindao logindao = new Logindao();
				userrole= logindao.getUserRole(userName, pass);
			}
		}

		return "User role is "+userrole;  
	}  

	@RequestMapping("/showallVendors")
	public String showAllVendors() {
		QueryDao vend = new QueryDao();
		vend.showAllVendor();
		return "showAllVendors";
	}

	@RequestMapping("/showJustVendors")
	public String showJustVendors() {
		QueryDao vend = new QueryDao();
		vend.showJustVendor();
		return "showJustVendor";
	}

	@RequestMapping("/addVendors")
	public String addVendors() {
		if(userrole.equals("admin")) {
			AdminDao admindao = new AdminDao();
			admindao.addItem();
		}
		return "addVendors";
	}

	@RequestMapping("/showByDish")
	public String showByDish() {
		//Scanner myObj2 = new Scanner(System.in);
		BufferedReader myObj2 = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Dish name :");
		String dishname=null;
		try {
			dishname = myObj2.readLine();
			//myObj2.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		if(dishname!=null) {
			QueryDao ven = new QueryDao();
			ven.showByDish(dishname);
		}
		return "showByDish";
	}

	@RequestMapping("/showByVendor")
	public String showByVendor() {
		Scanner myObj3 = new Scanner(System.in);
		System.out.println("Enter vendor name :");
		String vendorname= myObj3.nextLine();
		//myObj3.close();
		if(vendorname!=null) {
			QueryDao ven = new QueryDao();
			ven.showByVendor(vendorname);
		}
		return "showByVendor";

	}
	int val=1;
	List<Orderlist> list = new ArrayList<Orderlist>();
	@RequestMapping("/createOrder")
	public String createOrder() {
		try {
			Orderlist order = new Orderlist();
			Scanner ord = new Scanner(System.in);
			System.out.println("Enter Dish name :");
			String dishname= ord.nextLine();
			order.setDishname(dishname);
			System.out.println("Enter vendor name :");
			String vendorname= ord.nextLine();
			order.setVendorname(vendorname);
			System.out.println("Enter quantity :");
			int qty= ord.nextInt();
			order.setQty(qty);
			System.out.println("Do you want to add more ? Yes or No ");
			String yesNo= ord.nextLine();
			yesNo=ord.nextLine();
			if(!yesNo.isEmpty()) {
				QueryDao co = new QueryDao();
				int orderid=co.getOrderId()+val;
				order.setOrderid(orderid);
				float price =co.getByDishAndVendor(dishname , vendorname);
				float total = price*qty;
				order.setUnitprice(price);
				order.setTotalprice(total);

				long millis=System.currentTimeMillis();  
				java.sql.Date date=new java.sql.Date(millis);

				order.setDate(date);

				list.add(order);
				if(yesNo.equalsIgnoreCase("yes")) {

					this.createOrder();
				}else {


					co.createOrder(list);

					co.printOrderDetails(orderid);
				}
			}
			//ord.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return "createOrder";
	}

	@RequestMapping("/getAllOrders")
	public String getAllOrders() {
		if(userrole.equalsIgnoreCase("admin")) {
			QueryDao ven = new QueryDao();
			ven.getAllOrders();
		}
		return "getAllOrders";
	}

	@RequestMapping("/printByOrderAmt")
	public String printByOrderAmt() {
		if(userrole.equalsIgnoreCase("admin")) {
			Scanner poa = new Scanner(System.in);
			System.out.println("Enter asc or desc to get Order Details sorted by OrderAmount :");
			String type= poa.nextLine();
			QueryDao ven = new QueryDao();
			ven.printByOrderAmt(type);
		}
		return "printByOrderDate";
	}	
	@RequestMapping("/printByOrderDate")
	public String printByOrderDate() {
		if(userrole.equalsIgnoreCase("admin")) {
			Scanner pod = new Scanner(System.in);
			System.out.println("Enter asc or desc to get Order Details sorted by OrderDate :");
			String type= pod.nextLine();
			QueryDao ven = new QueryDao();
			ven.printByOrderDate(type);
		}
		return "printByOrderDate";
	}

	@RequestMapping("/showByPrice")
	public String showByPrice() {
		Scanner pri = new Scanner(System.in);
		System.out.println("Enter asc or desc to get Order Details sorted by Price :");
		String type= pri.nextLine();
		QueryDao ven = new QueryDao();
		ven.showByPrice(type);

		return "showByPrice";
	}
}  