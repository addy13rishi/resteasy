package com.example.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseHandler {

	// JDBC driver name and database URL
		static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
		static final String DB_URL = "jdbc:mysql://localhost:3306/restaurant";
		//  Database credentials
		static final String USER = "root";
		static final String PASS = "1qaz@WSX";
		
		public Connection conn = null;
		public Statement stmt = null;
		public java.sql.PreparedStatement prep_stmt = null;
		public CallableStatement call_stmt = null;
		
		public DatabaseHandler(){
			try{
				//STEP 2: Register JDBC driver
				//Class.forName("JDBC_DRIVER");

			    //STEP 3: Open a connection
			    conn = DriverManager.getConnection(DB_URL,USER,PASS);
			}
			
			catch(SQLException se){
			      //Handle errors for JDBC
			      se.printStackTrace();
			}catch(Exception e){
			      //Handle errors for Class.forName
			      e.printStackTrace();
		    }
		}  
		
		public void closeConn() {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
}
