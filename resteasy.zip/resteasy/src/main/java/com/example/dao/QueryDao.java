package com.example.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.example.bean.Orderlist;

public class QueryDao {

	
	public void showAllVendor() {

		DatabaseHandler db_handler = new DatabaseHandler();
		System.out.println("============================== MENU ==============================");
		System.out.println("VendorName         DishName              Price              Calories");
		System.out.println("------------------------------------------------------------------");
		try {
			db_handler.prep_stmt = db_handler.conn.prepareStatement("select v.vendorname as vendorname,d.dishname as dishname,v.dishprice as dishprice,d.dishcalories as dishcalories from vendor v join dish d on d.dishid=v.dishid");
			ResultSet items = db_handler.prep_stmt.executeQuery();
			while(items.next()) {
				System.out.printf("   %-12s%-24s%-22s%-10s",items.getString("vendorname"),items.getString("dishname"),items.getString("dishprice"), items.getString("dishcalories"));
				System.out.println();
			}
			items.close();
			db_handler.prep_stmt.close();
			db_handler.closeConn();
		}catch(SQLException se){
			se.printStackTrace();
		}
		System.out.println("------------------------------------------------------------------");

	}

	public void showJustVendor() {

		DatabaseHandler db_handler = new DatabaseHandler();
		System.out.println("============================== MENU ==============================");
		System.out.println("   VendorName   ");
		System.out.println("------------------------------------------------------------------");
		try {
			db_handler.prep_stmt = db_handler.conn.prepareStatement("select vendorname from vendor ");
			ResultSet items = db_handler.prep_stmt.executeQuery();
			while(items.next()) {
				System.out.printf("   %-12s",items.getString("vendorname"));
				System.out.println();
			}
			items.close();
			db_handler.prep_stmt.close();
			db_handler.closeConn();
		}catch(SQLException se){
			se.printStackTrace();
		}
		System.out.println("------------------------------------------------------------------");

	}
	public void showByVendor(String vendorName) {

		DatabaseHandler db_handler = new DatabaseHandler();
		System.out.println("============================== MENU ==============================");
		System.out.println("VendorName         DishName              Price              Calories");
		System.out.println("------------------------------------------------------------------");
		try {
			String sql = String.format("select v.vendorname as vendorname,d.dishname as dishname,v.dishprice as dishprice,d.dishcalories as dishcalories from vendor v join dish d on d.dishid=v.dishid where v.vendorname='%s'",vendorName);
			db_handler.prep_stmt = db_handler.conn.prepareStatement(sql);
			ResultSet items = db_handler.prep_stmt.executeQuery();
			while(items.next()) {
				System.out.printf("   %-12s%-24s%-22s%-10s",items.getString("vendorname"),items.getString("dishname"),items.getString("dishprice"), items.getString("dishcalories"));
				System.out.println();
			}
			items.close();
			db_handler.prep_stmt.close();
			db_handler.closeConn();
		}catch(SQLException se){
			se.printStackTrace();
		}
		System.out.println("------------------------------------------------------------------");

	}


	public void showByDish(String dishName) {

		DatabaseHandler db_handler = new DatabaseHandler();
		System.out.println("============================== MENU ==============================");
		System.out.println("VendorName         DishName              Price              Calories");
		System.out.println("------------------------------------------------------------------");
		try {
			String sql = String.format("select v.vendorname as vendorname,d.dishname as dishname,v.dishprice as dishprice,d.dishcalories as dishcalories from vendor v join dish d on d.dishid=v.dishid where d.dishname='%s'",dishName);
			db_handler.prep_stmt = db_handler.conn.prepareStatement(sql);
			ResultSet items = db_handler.prep_stmt.executeQuery();
			while(items.next()) {
				System.out.printf("   %-12s%-24s%-22s%-10s",items.getString("vendorname"),items.getString("dishname"),items.getString("dishprice"), items.getString("dishcalories"));
				System.out.println();
			}
			items.close();
			db_handler.prep_stmt.close();
			db_handler.closeConn();
		}catch(SQLException se){
			se.printStackTrace();
		}
		System.out.println("------------------------------------------------------------------");

	}

	public void createOrder(List<Orderlist> list) {

		DatabaseHandler db_handler = new DatabaseHandler();
		try {
			for(Orderlist o : list) {
			db_handler.prep_stmt = db_handler.conn.prepareStatement("insert into foodorder (orderid, dishname, vendorname, qty, unitprice, totalprice,orderdate) values (?,?,?,?,?,?,?)");
			db_handler.prep_stmt.setInt(1, o.getOrderid());
			db_handler.prep_stmt.setString(2, o.getDishname());
			db_handler.prep_stmt.setString(3, o.getVendorname());
			db_handler.prep_stmt.setInt(4, o.getQty());
			db_handler.prep_stmt.setFloat(5, o.getUnitprice());
			db_handler.prep_stmt.setFloat(6, o.getTotalprice());
			db_handler.prep_stmt.setDate(7, o.getDate());
			db_handler.prep_stmt.executeUpdate();
			//db_handler.prep_stmt.close();
			}
			db_handler.prep_stmt.close();
			db_handler.closeConn();
		}catch(SQLException se){
			se.printStackTrace();
		}
		finally{

		}
	}
	public float getByDishAndVendor(String dishName , String vendorName) {

		DatabaseHandler db_handler = new DatabaseHandler();
		float price =0f;
		try {
			String sql = String.format("select v.dishprice as dishprice from vendor v join dish d on d.dishid=v.dishid where d.dishname='%s' and v.vendorname='%s'",dishName,vendorName);
			db_handler.prep_stmt = db_handler.conn.prepareStatement(sql);
			ResultSet items = db_handler.prep_stmt.executeQuery();
			while(items.next()) {
				price=items.getFloat("dishprice");
				System.out.println("Price from Menu based on vendor and dish :"+price);
			}
			items.close();
			db_handler.prep_stmt.close();
			db_handler.closeConn();
		}catch(SQLException se){
			se.printStackTrace();
		}
		return price;
	}

	public int getOrderId() {

		DatabaseHandler db_handler = new DatabaseHandler();
		int count =0;
		try {
			String sql = String.format("select max(orderid) as count from foodorder");
			db_handler.prep_stmt = db_handler.conn.prepareStatement(sql);
			ResultSet items = db_handler.prep_stmt.executeQuery();
			while(items.next()) {
				count=items.getInt("count");
				System.out.println("Max order id :"+count);
			}
			items.close();
			db_handler.prep_stmt.close();
			db_handler.closeConn();
		}catch(SQLException se){
			se.printStackTrace();
		}
		return count;
	}
	
	
	public void printOrderDetails(int orderid) {
		float orderTotal =0f;
		DatabaseHandler db_handler = new DatabaseHandler();
		System.out.println("============================== MENU ===============================================================");
		System.out.println("    DishName         VendorName         Qty               Unit Price            Total Price");
		System.out.println("----------------------------------------------------------------------------------------------------");
		try {
			String sql = String.format("select dishname ,vendorname,qty , unitprice,totalprice from foodorder where orderid='%s'",orderid);
			db_handler.prep_stmt = db_handler.conn.prepareStatement(sql);
			ResultSet items = db_handler.prep_stmt.executeQuery();
			while(items.next()) {
				System.out.printf("   %-12s%-24s%-22s%-22s%-10s",items.getString("dishname"),items.getString("vendorname"),items.getString("qty"), items.getString("unitprice") , items.getString("totalprice"));
				System.out.println();
				orderTotal+=items.getFloat("totalprice");
			}
			items.close();
			System.out.println("Order Total Price :"+orderTotal);
			db_handler.prep_stmt.close();
			db_handler.closeConn();
		}catch(SQLException se){
			se.printStackTrace();
		}
		finally{

		}
	}
	
	
	public void getAllOrders() {
		float orderTotal =0f;
		DatabaseHandler db_handler = new DatabaseHandler();
		System.out.println("============================== MENU ===============================================================");
		System.out.println("    DishName         VendorName         Qty               Unit Price            Total Price");
		System.out.println("----------------------------------------------------------------------------------------------------");
		try {
			String sql = String.format("select dishname ,vendorname,qty , unitprice,totalprice from foodorder");
			db_handler.prep_stmt = db_handler.conn.prepareStatement(sql);
			ResultSet items = db_handler.prep_stmt.executeQuery();
			while(items.next()) {
				System.out.printf("   %-12s%-24s%-22s%-22s%-10s",items.getString("dishname"),items.getString("vendorname"),items.getString("qty"), items.getString("unitprice") , items.getString("totalprice"));
				System.out.println();
				orderTotal+=items.getFloat("totalprice");
			}
			items.close();
			System.out.println("Order Total Price :"+orderTotal);
			db_handler.prep_stmt.close();
			db_handler.closeConn();
		}catch(SQLException se){
			se.printStackTrace();
		}
		
	}
	
	
	public void printByOrderAmt(String type) {
		float orderTotal =0f;
		DatabaseHandler db_handler = new DatabaseHandler();
		System.out.println("============================== MENU ===============================================================");
		System.out.println("    DishName         VendorName         Qty               Unit Price            Total Price");
		System.out.println("----------------------------------------------------------------------------------------------------");
		try {
			String sql = String.format("select dishname ,vendorname,qty , unitprice,totalprice from foodorder order by totalprice %s",type);
			db_handler.prep_stmt = db_handler.conn.prepareStatement(sql);
			ResultSet items = db_handler.prep_stmt.executeQuery();
			while(items.next()) {
				System.out.printf("   %-12s%-24s%-22s%-22s%-10s",items.getString("dishname"),items.getString("vendorname"),items.getString("qty"), items.getString("unitprice") , items.getString("totalprice"));
				System.out.println();
				orderTotal+=items.getFloat("totalprice");
			}
			items.close();
			System.out.println("Order Total Price :"+orderTotal);
			db_handler.prep_stmt.close();
			db_handler.closeConn();
		}catch(SQLException se){
			se.printStackTrace();
		}
		
	}
	
	public void printByOrderDate(String type) {
		float orderTotal =0f;
		DatabaseHandler db_handler = new DatabaseHandler();
		System.out.println("============================== MENU ===============================================================");
		System.out.println("    DishName         VendorName         Qty               Unit Price            Total Price		OrderDate");
		System.out.println("----------------------------------------------------------------------------------------------------");
		try {
			String sql = String.format("select dishname ,vendorname,qty , unitprice,totalprice ,orderdate from foodorder order by orderdate %s",type);
			db_handler.prep_stmt = db_handler.conn.prepareStatement(sql);
			ResultSet items = db_handler.prep_stmt.executeQuery();
			while(items.next()) {
				System.out.printf("   %-12s%-24s%-22s%-22s%-10s",items.getString("dishname"),items.getString("vendorname"),items.getString("qty"), items.getString("unitprice") , items.getString("totalprice"), items.getString("orderdate"));
				System.out.println();
				orderTotal+=items.getFloat("totalprice");
			}
			items.close();
			System.out.println("Order Total Price :"+orderTotal);
			db_handler.prep_stmt.close();
			db_handler.closeConn();
		}catch(SQLException se){
			se.printStackTrace();
		}
		
	}
	
	
	public void showByPrice(String type) {

		DatabaseHandler db_handler = new DatabaseHandler();
		System.out.println("============================== MENU ==============================");
		System.out.println("VendorName         DishName              Price              Calories");
		System.out.println("------------------------------------------------------------------");
		try {
			String sql = String.format("select v.vendorname as vendorname,d.dishname as dishname,v.dishprice as dishprice,d.dishcalories as dishcalories from vendor v join dish d on d.dishid=v.dishid order by v.dishprice %s",type);
			db_handler.prep_stmt = db_handler.conn.prepareStatement(sql);
			ResultSet items = db_handler.prep_stmt.executeQuery();
			while(items.next()) {
				System.out.printf("   %-12s%-24s%-22f%-10s",items.getString("vendorname"),items.getString("dishname"),items.getFloat("dishprice"), items.getString("dishcalories"));
				System.out.println();
			}
			items.close();
			db_handler.prep_stmt.close();
			db_handler.closeConn();
		}catch(SQLException se){
			se.printStackTrace();
		}
		System.out.println("------------------------------------------------------------------");

	}

}
