package com.example.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class AdminDao {

	int dishid=0;
	public void addItem() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Vendor name: ");
		String vendor_name = sc.nextLine();
		System.out.print("Dish name: ");
		String dish_name = sc.nextLine();
		System.out.print("Item price: ");
		float item_price = sc.nextFloat();
		System.out.println("Dish calories :");
		String dish_calories = sc.nextLine();
		dish_calories = sc.nextLine();
		sc.close();
		DatabaseHandler db_handler = new DatabaseHandler();
		try {
			db_handler.prep_stmt = db_handler.conn.prepareStatement("insert into dish (dishname, dishcalories) values (?,?)");
			db_handler.prep_stmt.setString(1, dish_name);
			db_handler.prep_stmt.setString(2, dish_calories);
			
			db_handler.prep_stmt.executeUpdate();
			
			String sql = String.format("select dishid from dish where dishname='%s'",dish_name);
      	  
			db_handler.prep_stmt = db_handler.conn.prepareStatement(sql);
			ResultSet items = db_handler.prep_stmt.executeQuery();
	
			while(items.next()) {
				dishid=items.getInt("dishid");
				System.out.printf("Dish name  " +dish_name + " entered with dishId "+dishid);
				System.out.println();
				
			}
			
			db_handler.prep_stmt = db_handler.conn.prepareStatement("insert into vendor (vendorname,dishid,dishprice) values (?,?,?)");
			db_handler.prep_stmt.setString(1, vendor_name);
			db_handler.prep_stmt.setInt(2,dishid);
			db_handler.prep_stmt.setFloat(3, item_price);
			
			db_handler.prep_stmt.executeUpdate();
			
			db_handler.prep_stmt.close();
		}catch(SQLException se){
		   se.printStackTrace();
		}
	}
}
