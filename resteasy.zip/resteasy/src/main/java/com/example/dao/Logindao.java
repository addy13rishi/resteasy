package com.example.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Logindao {
	String userrole=null;


	public String getUserRole(String user , String pass){
		DatabaseHandler db_handler = new DatabaseHandler();
        try {
        	String sql = String.format("select userrole from login where userid='%s' and password='%s'",user,pass);
        	  
			db_handler.prep_stmt = db_handler.conn.prepareStatement(sql);
			ResultSet items = db_handler.prep_stmt.executeQuery();
	
			while(items.next()) {
				userrole=items.getString("userrole");
				System.out.printf("You are logged in as " +user + "with role "+userrole);
				System.out.println();
				
			}
			items.close();
			db_handler.prep_stmt.close();
		}catch(SQLException se){
		   se.printStackTrace();
		}
		System.out.println("------------------------------------------------------------------");
		return userrole;
	} 
	
}
