package com.example.controller;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;

public class SpringBootJdbcControllerTest {
	
	@InjectMocks
	private SpringBootJdbcController springBootJdbcController;
	
	
	
	
	 @Test
	 public void loginCall01() throws Exception {
//		 Scanner mockScanner = mock(Scanner.class);
//		 Mockito.when(mockScanner.nextLine()).thenReturn("admin");
//		 Mockito.when(mockScanner.nextLine()).thenReturn("admin");
		 springBootJdbcController.loginCall();
	    }

}
